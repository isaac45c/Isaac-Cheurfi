# FlightSim

This is git repo for this blog post: https://vazgriz.com/346/flight-simulator-in-unity3d-part-1/

You must use Git LFS to download this project.

The project at tag `part-1`:

![](https://vazgriz.com/wp-content/uploads/2021/01/part-1-1024x575.png)
